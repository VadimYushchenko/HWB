=== Sliding Widgets ===
Contributors: codename065, shahriar0822
Donate link:  http://wpeden.com
Tags: widget, sidebar, widgets, sliding widget, sliding widgets, slider, sliding panel
Requires at least: 3.5
Tested up to: 3.8
 
 

WordPress Sliding Widgets Plugin will help your to create a sliding widget area dynamically.  
   

== Description ==

WordPress Sliding Widgets Plugin will help your to create a sliding panel dynamically where you can place any number of widget as you do for regular sidebar from WordPress widget manager. You can setup the position anywhere at left, right, top or bottom. 

== Installation ==

1. Upload `sliding-widgets` to the `/wp-content/plugins/`  directory
2. Activate the plugin through the 'Plugins' menu in WordPress


== Screenshots ==
1. Sliding Widget
2. Settings page

== Changelog ==

= 1.1.0 = 
* Regular maintenance & compatibility release for wp 3.8

= 1.0.3 =
* adjusted css with top and bottom positioning

= 1.0.2 =
* adjusted css issue for text widget, left and right widget areas

= 1.0.1 =
* adjusted "px" issue with height and width

= 1.0.0 =
* initial release

