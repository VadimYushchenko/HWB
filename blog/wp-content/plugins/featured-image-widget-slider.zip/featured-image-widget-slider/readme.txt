=== Featured Image Widget Slider ===
Contributors: CuvixSystem
Donate link: 
Tags: Featured , Image , Category , Widget , Slider
Requires at least: 3.3
Tested up to: 3.8
Stable tag: 1.0
License: GPLv2 or later
License URI: http://cuvixsystem.com/licenses/

Get 10 newest featured image from a selected category in a sidebar widget as a slider.

== Description ==

Featured Image Widget Slider is a plugin by which you can get 10 newest featured image from a selected category in a sidebar widget as a slider you can set width and height of slider also. On Click slider image related post of the featured image will open.

== Installation ==

1. Upload `plugin` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. You will get a widget in widget list
4. Drag it to sidebar pannel

== Frequently asked questions ==



== Screenshots ==

1. admin widget column
2. Frontend sidebar column

== Changelog ==



== Upgrade notice ==



== Arbitrary section 1 ==