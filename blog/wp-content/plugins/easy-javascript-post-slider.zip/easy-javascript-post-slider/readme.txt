=== Simple Image Slider ===
Contributors: <a href ="http://profiles.wordpress.org/uvesh123" target="_blank" >Perception System</a>
Donate link: http://www.perceptionsystem.com
Tags: simple slider, image slider, image rotator, photo slider
Requires at least: 3.0
Tested up to: 3.6-alpha
Stable tag: 2.6
License: GPLv2 and (components under MIT License)
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Simple Image Slide permits users to create Image Slide Show.

== Description ==

SIS allows to create Simple Slider With that you can create a slide just like a page and insert a media gallery with add media button. By adding image gallery, publish the slide(page) and you will get the shortcode with slide ID for the particular slide at the slider main column. Use this shortcode in your post or page editor then publish it. You have a simple rotating image slider on your page.
For more products : http://www.store.perceptionsystem.com/wordpress-theme-mobile-app-promption-themes-red.html

== Installation ==

1. Upload 'Simple Slider' to the wordpress admin
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Open Simple Slider and add a slide
4. insert the image gallery using 'add media' button

== Frequently Asked Questions ==

1. What is use of Simple Image Slider plug-in? 
Using this plug-in, you can display your Image Gallery as Gallery Slide Show.

2. How can we use Simple Image Slider plug-in? 
Simple Image Slider plug-in is very easy to use. You just have to install your plug-in like others and manage your slides on the left side menu bar according to requirements. 

3. How can we display Image Slider in page/post? 
You Have to copy the shortcode for example ([simple_image_slider id=1]) for the image slide and paste it in your page editor.

== Screenshots ==

1.How to add New slide using post type as slider
2.Add New gallery using Add to media section
3.Select images for gallery
4.Added new gallery in slider post
5.Display Shortcodes in slide list page , to use shortcodes in any  posts/pages
6.Added Slider short codes in new pages 
7.Display gallery in front side
