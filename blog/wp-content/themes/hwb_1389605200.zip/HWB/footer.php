<?php
/**
 * Created by PhpStorm.
 * User: vadimyushchenko
 * Date: 1/5/14
 * Time: 12:33 AM
 */
?>

<!--Footer-->
<footer id="footer">

    <div class="bottom clearfix">
        <!--Holder 1140-->
        <div class="holder1140 clearfix">

            <p>&copy; 2013. <span>HWB</span> All Rights Reserved.</p>
            <ul>
                <li><a href="#">Privacy</a></li>
                <li><a href="#">Support</a></li>
                <li><a href="#">Terms</a></li>
            </ul>

        </div>
        <!--Holder 1140-->

    </div>


</footer>
<!--End footer-->